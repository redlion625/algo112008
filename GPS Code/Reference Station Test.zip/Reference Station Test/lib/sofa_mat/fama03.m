function a = fama03(t) 
   a = rem(6.203480913 + 334.0612426700 * t, Const.D2PI);