function a = fave03(t)
 a = rem(3.176146697 + 1021.3285546211 * t, Const.D2PI);