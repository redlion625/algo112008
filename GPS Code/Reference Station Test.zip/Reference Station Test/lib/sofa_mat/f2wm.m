function r = f2wm(gamb,phib,psi,eps)
