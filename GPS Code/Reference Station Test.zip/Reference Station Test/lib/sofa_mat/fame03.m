function a = fame03(t)
a = rem(4.402608842 + 2608.7903141574 * t, Const.D2PI);