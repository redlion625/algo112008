function a = faur03(t)
a = rem(5.481293872 + 7.4781598567 * t, Const.D2PI);