function a = faju03(t)
   a = rem(0.599546497 + 52.9690962641 * t, Const.D2PI);