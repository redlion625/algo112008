function [x,y] = bpn2xy(rbpn)
x = rbpn(3,1);
y = rbpn(3,2);