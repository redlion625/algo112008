function a = fasa03(t)
   a = rem(0.874016757 + 21.3299104960 * t, Const.D2PI);