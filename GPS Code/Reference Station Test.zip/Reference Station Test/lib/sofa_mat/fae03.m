function a = fae03(t)
a = rem(1.753470314 + 628.3075849991 * t, Const.D2PI);