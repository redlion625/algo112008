function a = fapa03(t)
% General accumulated precession in longitude. */
   a = (0.024381750 + 0.00000538691 * t) * t;