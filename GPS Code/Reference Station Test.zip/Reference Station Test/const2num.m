function num = const2num(const)
if const == "G"
    num = 1;
elseif const == "R"
    num = 2;
else
   num = 69;
end