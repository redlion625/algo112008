function gast = getGAST_PLS(uta,utb)
