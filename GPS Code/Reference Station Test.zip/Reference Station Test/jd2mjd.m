function mjd = jd2mjd(jd)
mjd=jd-2400000.5;