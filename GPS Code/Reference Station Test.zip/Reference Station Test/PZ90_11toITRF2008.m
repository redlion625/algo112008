function [x,y,z]=PZ90_11toITRF2008(x0,y0,z0)
% 
% Notes:
% GLONASS navigation methods from 2014 onward follow 
% PZ90.11

x=x0-0.003;
y=y0-0.001;
z=z0;